---
layout: post
title: Mathjax Test
subtitle: My first mathjax expression
categories: markdown
tags: [test]
---

* A safe integer is an integer that
  * can be exactly represented as an IEEE-754 double precision number, and
  * whose IEEE-75 representation cannot be the result of rounding any other integer to fit the IEEE-754 representation
* For example, $ 2 ^ {53} - 1 $ is a safe integer,
  * it can be exactly represented 
